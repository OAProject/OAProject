//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"





/***************************************************************/
// why 18 1.88
// 1:使用数组保存信息
let array : [Any] = ["why",18,1.88]
// 取出的值是Any类型
let arrayName = array[0] as! String
// 获取arrayName长度
print(arrayName.characters.count)






/***************************************************************/
// 2:使用字典保存信息
let dict : [String : Any] = ["name" : "shy","age" : 18, "height" : 1.88]
let dictName = dict["name"] as! String
print(dictName.characters.count)
// 注意:如果let dictName = dict["age"] as! String  就会报错






/***************************************************************/
// 3:使用元组保存信息 
// 写法1:
let info = ("why",18,1.88)
let name = info.0
let age = info.1
print(name.characters.count)

// 写法2:起别名<常见>
let info1 = (name :"why", age : 18, height : 1.88)
let name1 = info1.name
let age1 = info1.age


// 写法3:
let (name2 , age2 , height2) = ("why",18,1.88)
name2
age2
height2












