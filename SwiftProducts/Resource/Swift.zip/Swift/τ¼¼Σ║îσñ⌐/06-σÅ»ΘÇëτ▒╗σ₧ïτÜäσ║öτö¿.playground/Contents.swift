//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

// 只要一个类型有可能为nil，那么这个标识符的类型一定是一个可选类型






// 应用场景1:

//: 1:将字符串转成int类型
let m : Double = 2.14
let n = Int(m)

let str : String = "123"
let num : Int? = Int(str) // 123/nil







// 应用场景2:

// 2.根据文件名称123.plist，获取改文件的路径
let path : String? = Bundle.main.path(forResource: "123.plist", ofType: nil) // string/nil







// 应用场景3:

// 3.将字符串转成NSURL,如果字符串有中文，那么就是转化不成功，返回结果为nil
let url = URL(string: "http://www.520it.com")








// 应用场景4:

// 从字典中取出元素
let dict : [String : Any] = ["name" : "why", "age" : 18]
let value : Any? = dict["name"] // Any/nil
print(value)



























