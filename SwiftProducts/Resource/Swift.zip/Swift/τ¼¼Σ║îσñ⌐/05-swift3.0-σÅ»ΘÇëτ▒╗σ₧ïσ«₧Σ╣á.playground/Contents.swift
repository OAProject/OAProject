//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/**
 可选类型:
    1:定义可选类型
         1> optional<String>
         2> String?
    2:给可选类型进行赋值
         1> optional("why")
         2> "why"
    3:取出可选类型的值
         name! --> 强制解包
    4:注意：强制解包非常危险，所以先判断是非为空，在解包
    5:语法:可选绑定
         if name = name {
            print(name)
        }
 
 */







//var name : String
//
//name = "123"

// 在类里面要求对所有成员属性都要进行赋值
// 在开发中，只有可选类型才能赋值nil，其它类型都不能赋值为nil

class Person {
    var name : String = ""
    // nil也是一种特殊类型，所以不能复制给字符串空值的情况下，这种会报错
    //var name1 : String = nil
}





/******************************************/
// 1:定义可选类型
// 定义方式1:
//var name2 : Optional<String> = nil

// 语法糖写法2:
var name2 : String? = nil





/******************************************/
// 2:给可选类型赋值
// 2.1:赋值方式1
//name2 = Optional("why1")

// 2.2:赋值方式2,编译器会自动帮你做好类型一致
name2 = "why2"





/******************************************/
// 3:取出可选类型
print(name2)
// 从可选类型值取值：可选类型 ＋ ！ －－>强制解包
print(name2!)





/******************************************/
// 4:注意：强制解包会非常危险，如果可选类型为nil，那么强制解包就会崩溃
if name2 != nil {
    print(name2!)
}




/******************************************/
// 最终安全写法:
// 5:可选绑定：该语法应用于可选类型，使我们使用起来更加方便
// 解读：1> 判断name是否有值，如果没有值，则直接不执行
//      2> 如果name有值，那么系统会自动对可选类型进行解包，并且将解包后的结果赋值给name
if let name2 = name2 {
    print("最终写法:\(name2)")
}



