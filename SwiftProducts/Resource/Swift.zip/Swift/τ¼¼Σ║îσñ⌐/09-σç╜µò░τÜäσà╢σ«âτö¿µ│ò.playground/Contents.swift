//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/*
 1:内部参数和外部参数
 2:可变参数，参数的个数是可变
 3:默认参数：可以给某一个参数提供一个默认值
 4:指针参数: inout
 */




// 1.内部参数 && 外部参数
// 内部参数：在函数内部能看到标识符名称，该标识符就是内部参数
// 外部参数：在函数外部能看到标识符名称，该标识符就是外部参数
// 默认情况下:所有参数都是内部参数也是外部参数
// 修改外部参数：如果想要修改外部参数名称和内部参数名称不一样，在标识符前加上外部参数名称即可
// 如果不希望显示外部参数，可以在标识符前加上_
func sum0(num1 : Int, num2 : Int) -> Int {
    return num1 + num2
}
let result0 = sum0(num1: 20, num2: 30)



// 修改外部参数：如果想要修改外部参数名称和内部参数名称不一样，在标识符前加上外部参数名称即可
func sum1(age num1 : Int, num2 : Int) -> Int {
    return num1 + num2
}
let result1 = sum0(num1: 20, num2: 30)
let resul1 = sum1(age: 18, num2: 20)




// 如果不希望显示外部参数，可以在标识符前加上_
func sum2(_ num1 : Int, _ num2 : Int) -> Int {
    return num1 + num2
}
let result = sum2(18, 20)












// 2.可变参数
// 遇到将所有Int类型数据相加，不可能一个一个相加
func sum3(_ nums : Int...) -> Int {
    var total = 0
    for n in nums {
        total += n
    }
    return total
}
//sum3(nums: 20,30,40,50)
//print(sum3(nums: 20,30,40,50))
print(sum3(20,30,40,50))











// 3.默认参数
func makecoffee(coffeeName : String = "雀巢") -> String {
    return "制作了一杯:\(coffeeName)咖啡"
}
makecoffee(coffeeName: "拿铁")
makecoffee(coffeeName: "豆浆")
makecoffee()











// 4.指针参数
// swift3.0 inout 写法如下，想要交换数值，我们需要传递地址，而不是值传递
var m : Int = 20
var n : Int = 30

func swapNum(num1 : inout Int, num2 : inout Int) {
    let tempNum = num1
    num1 = num2
    num2 = tempNum
}
swapNum(num1: &m, num2: &n)
print("m = \(m),n = \(n)")
























