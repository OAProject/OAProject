//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/**
 字典的使用
    1:字典的定义
        1> 不可变字典：let修饰
        2> 可变字典：var修饰
    2:对可变字典的基本操作
        增删改查
    3:遍历字典
        1> 所有的key
        2> 所有的value
        3> 所有的key／value
    4:字典的合并
 */








// 1:定义字典
// 1> 定义不可变字典:使用let 修饰
// 值：可能有很多中类型string/int/double等等
// 编译器会根据[]中是一个个元素（数组），还是键值对（字典）
//let dict : Dictionary<String,Any> = ["name" : "XJDomain","age" : 18]
// 推荐写法:
let dict1 : [String : Any] = ["123":"321","age" : 18]


// 2> 定义可变数组:使用var修饰
var dictM1 = Dictionary<String , Any>()
var dictM = [String : Any]()
var dictM2 : [String : Any] = Dictionary()




// 2:对可变字典的基本操作<增删改查>
// 2.1:添加元素
dictM["name"] = "xjdomain"
dictM["age"] = "11"
dictM["height"] = "1.88"
dictM

// 2.2:删除元素
dictM
dictM.removeValue(forKey: "name")
dictM


// 2.3:修改元素
// 方式1
dictM["name"] = "fxj"
dictM

// 方式2:
dictM.updateValue("lsb", forKey: "name")
dictM
print(dictM)
print("----------------------------11111")


// 3:遍历字典
// 3.1:遍历字典中所有的key
for key in dictM.keys {
    print(key)
}


print("---------------------------2222")
// 3.2:遍历字典中所有的value
for value in dictM.values {
    print(value);
}

// 3.3:遍历字典中所有的key／value
for (key,value) in dictM {
    print(key,value)
}


// 4:字典合并
let dict01 : [String : Any] = ["name" : "abc","age" : 18]
let dict02 : [String : Any] = ["height" : 1.88,"phoneNum" : "+86 110"]
//let result = dict01 + dict02
// 字典是不可以相加合并的

// 合并解决方法
for (key,value) in dict02 {
    dictM1[key] = value
}

print("+++++++++++")
print(dictM1)








