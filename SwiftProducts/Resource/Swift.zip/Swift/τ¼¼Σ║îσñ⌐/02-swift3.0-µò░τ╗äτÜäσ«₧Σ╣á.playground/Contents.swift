//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/**
  数组的使用:
     1:数组的定义
         1> 定义不可变数组
         2> 定义可变数组
     2:对可变数组的基本操作
         增删改查
     3:数组的遍历
        1> 获取数组的长度
        2> 数组的遍历（3中方式）（i／item／index-item）
     4:数组的合并<相同元素才可以合并数组>
 */



/****************************************************************/
// 1:数组的定义
   // 1> 定义不可变数组:使用let修饰
   // 数组的类型: 1> Array<String>   2> [String](推荐写法)
let array : Array<String> = ["1","2","3"]
   // 写法二:let array = ["1","2","3"]


   // 2> 定义可变数组: 使用var修饰
var arrayM : [String] = Array()
var arrayM1  = [String]()
var arrayM2 = Array<String>()



/****************************************************************/
// 2:对可变数组的基本操作
// 增删改查
// 2.1添加元素
arrayM1.append("李胜兵")
arrayM1.append("小马哥")
arrayM1.append("李胜兵")
arrayM1.append("国庆节")

// 2.2删除元素
arrayM1.remove(at: 0)
arrayM1

// 2.3修改元素
arrayM1[0] = "付晓婕"
arrayM1

// 2.4获取元素
arrayM1[0]







/****************************************************************/
// 3:对数组的遍历
let count = arrayM1.count


print("-----------方式1--------------")
// 3.1:这种遍历方式可以－－获取到下标识
for i in 0..<count {
    print(arrayM1[i])
}
print("-----------方式2--------------")

// 3.2: 不需要使用到下标值的遍历方法
for item in arrayM1 {
    print(item)
}

print("-----------推荐方式3--------------")
// 3.3: 对数组的遍历(既能获取到下标值，又能获取到元素)
for (index,item) in arrayM1.enumerated() {
    print(item,index)
}






/****************************************************************/
// 4:数组的合并

// 4.1:如果数组中存放的是相同的元素，那么在swift中可以对两个数组直接相加
let array01 = ["1","2","3"]
let array02 = ["4","5","6"]
let array03 = array01 + array02
print(array03)

// 4.2:如果存放的是不相同的元素，就不能相加处理




