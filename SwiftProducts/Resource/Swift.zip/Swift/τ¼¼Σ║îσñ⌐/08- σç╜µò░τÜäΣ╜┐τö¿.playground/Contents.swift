//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


// 函数的使用


// 1.没有参数，没有返回值
func about() -> Void {
    print("iphone8")
}
about()

// 简写:
func about01() {
    print("简单写法iphone8")
}
about01()















// 2.有参数，没有返回值
func callPhone(phoneNum : String) {
    print("打电话给:\(phoneNum)")
}
callPhone(phoneNum: "+86 110")
















// 3.没有参数，有返回值
func readMsg() -> String {
    return "吃饭了吗?"
}
readMsg()
let msg = readMsg()
print(msg)


















// 4.有参数，有返回值
func sum(num1 : Int, num2 : Int) -> Int {
    return num1 + num2
}
sum(num1: 10, num2: 100)
let result = sum(num1: 10, num2: 100)
print(result)


