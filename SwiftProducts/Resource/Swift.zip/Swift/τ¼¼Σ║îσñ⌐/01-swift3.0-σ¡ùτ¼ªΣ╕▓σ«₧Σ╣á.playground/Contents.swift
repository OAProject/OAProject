//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/**
 1:字符串的定义 
   1> 不可变字符串的定义
   2> 可变字符串的定义
 
 2:获取字符串的长度
 
 3:字符串的拼接
    1> 字符串之间的拼接
    2> 字符串与其它字符串之间的拼接 "\(标识符)"
    3> 字符串拼接过程中格式化:String("format:%d:%d",参数,参数)
 
 4:字符串的截取
    1> 方式一: 将String转成NSString ,在进行截取(推荐)
    2> 方式二: 直接使用String中方法,进行截取. String.index
 */




/******************************************************/
// 定义字符串
//let str : String = "123"
//var str : String = "123"
//let :定义的是不可变字符串   var :定义的是可变字符串




/******************************************************/
// 字符串的长度
let str1 : String = "123"
let length = str1.characters.count



/******************************************************/
// 字符串拼接
// >1:字符串与字符串之间的拼接
let str2 : String = "456"
let str3 : String = "678"
let str4 = str2 + str3


// >2:字符串与其它标识之间的拼接
let name = "XJDomain"
let age = 26
let height = 170
let infoStr = "my name is:\(name), my age is :\(age), my height is :\(height)"


// >3:字符串拼接过程中的格式化 03:04
let min = 3
let second = 4
let timeStr = String(format: "%02d:%02d", min,second)




/******************************************************/
// 4.字符串截取
let urlString = "www.520it.com"
// >4.1方式一：将String类型转成NSString类型，在进行截取：as NSString
let header1 = (urlString as NSString).substring(to: 3)
let range = NSMakeRange(4, 5)
let middle1 = (urlString as NSString).substring(with: range)
let footer1 = (urlString as NSString).substring(from: 10)


// 4.2方式二:直接使用String类型方法，进行截取
let headerIndex = urlString.index(urlString.startIndex, offsetBy: 3)
let header2 = urlString.substring(to: headerIndex)
















































