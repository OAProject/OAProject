//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// 1:枚举类型的定义
enum MethodType {
    case get
    case post
    case put
    case delete
}

enum MethodType1 : String {
    case get = "get"
    case post = "post"
    case put = "put"
    case delete = "delete"
}

// 2:创建枚举具体的值
let type1 : MethodType = .get
let type2 = MethodType.post

// 3:给枚举类型进行赋值
//  如果枚举没有赋值的话是没有值的，不像oc中默认依次是0.1.2.3....
enum Direction : Int {
    case east = 0
    case west = 1
    case north = 2
    case south = 3
}

let d : Direction = .east
// 只有赋值才会有这种创建方式：可选类型
let d1 = Direction(rawValue: 1)


// 4:枚举类型定义方式二
enum Type  {
    case get, post, put, delete
}
// 只针对Int类型，会自动为0.1.2.3
enum Type1 : Int  {
    case get = 0, post, put, delete
}

let type111 = Type1(rawValue: 1)
print(type111)

