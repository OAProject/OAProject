//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


// 1.类的定义

/* oc类的定义:
 
 @interface Person : NSObject
 @end
 
 @impelment
 @end
 */


/* swift中定义类：也可以继承NSObject：如果不需要使用到NSObject中相关的kvc特性之类的就不需要继承自NSObject，这样类会更加轻量级点
class 类名称 {
    
}
*/


class Person {
    
    // 如果属性是值类型，则初始化为空值
    // 如果属性是对象类型，则初始化为nil值
    //var name : String = ""
    var name : String?
    var age : Int = 0
    var view : UIView?
}


// 2.创建类的对象
let view = UIView()
let p = Person()
p.name = "why"
p.age = 29
p.view = view










