//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


class Person : NSObject{
    var name : String = ""
    var age : Int = 0
    
    
    // 在swift开发中，如果在对象方法中，用到了成员属性，那么self可以省略
    // 注意：如果在函数中，有何成员属性重名的局部变量，那么self，不能省略
    
    // 注意：如果有自定义构造函数，那么会将系统提供的构造函数覆盖掉.除非你要手动去声明init(){}这个系统方法
    override init() {
        
    }
    
    init(name : String, age : Int) {
        self.name = name
        self.age = age
    }
    
    
    // Dictionary<String, Any>
    init(dict : [String : Any]) {
        if let name = dict["name"] as? String {
            self.name = name
        }
        
        if let age = dict["age"] as? Int {
            self.age = age
        }
    }
    
    // 通过kvc一次性将字典转换比较简单
    /*
    1.使用kvc条件
     1> 必须继承自NSObject
     2> 必须在构造函数中，先调用super.init()
     3> 调用setValuesForKeys(dictkvc)
     4> 如果字典中某一个key没有对应的属性，则需要重写下面这个方法：就不会崩溃
     // override func setValue(_ value: Any?, forUndefinedKey key: String) {}
 
 
    */
    init(dictkvc : [String : Any]) {
        super.init()
        setValuesForKeys(dictkvc)
    }
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {}
}


let p = Person()
p.name = "why"
p.age = 18


let p1 = Person(name: "why", age: 20)
let p2 = Person(dict: ["name" : "fxj", "age" : 26])
print(p2.name,p2.age)






























