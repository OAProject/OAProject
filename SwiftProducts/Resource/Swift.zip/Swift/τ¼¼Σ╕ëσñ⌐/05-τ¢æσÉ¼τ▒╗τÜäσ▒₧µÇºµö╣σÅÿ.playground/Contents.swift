//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


class Person {
    // 属性监听器
    var name : String = "" {
        
        // 选中其中之一即可，开发当中这个方法一般都是选中其一就可以了
        // 监听属性即将发生改变：还没有改变
        //willSet (newName)这样可以改变了原来的名字：newValue
        willSet (newName) {
            print("属性即将发生改变:\(name)")
            print("属性即将发生改变newValue=\(newName)")
        }
        
        // 监听属性已经发生改变：已经改变
        didSet {
            print("已经发生改变:\(name)")
            print("已经发生改变:oldValue=\(oldValue)")
        }
    }
}


let p = Person()
p.name = "XJdomain"