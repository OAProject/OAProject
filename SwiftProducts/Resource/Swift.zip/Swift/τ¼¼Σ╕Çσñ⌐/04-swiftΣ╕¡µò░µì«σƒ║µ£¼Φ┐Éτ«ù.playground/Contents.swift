//: Playground - noun: a place where people can play

import UIKit
// playfround 只能书写swift语法，不能书写OC代码

//int m = 20
//int n = 30.5
//int result = m + n

let m = 20
let n = 3.14

// 将整形转成浮点型Double(标志符)
let tempM = Double(m)
// let result = m + n 错误运算
let result = tempM + n

// 将浮点型转成整形:Int(标志符)
let tempN = Int(n)
let result1 = tempN + m










