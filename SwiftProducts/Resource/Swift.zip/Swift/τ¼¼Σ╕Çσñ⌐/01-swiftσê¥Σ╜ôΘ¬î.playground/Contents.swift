//: Playground - noun: a place where people can play


// 1:swift中如何导入框架
//#import <UIKit/UIkit.h>
import UIKit





// 2:定义标志符
//int a = 20;
//swift中定义的标志符：定义的标志符必须告诉编译器是一个常量还是一个变量
// 声明常量使用let修饰
// 声明变量使用var修饰

//let/var 标志符的名称 :标志符的数据类型 = 值
let a :Int = 20
// a = 30 错误写法(常量是不能修改的)
var b : Double = 1.44
b = 2.44




// 3:语句结束
// 如果一行中只有一条语句，那么该语句结束后，可以不加; ,可以省略
// 如果一行中有多条语句，那么需要以;分割




// 4:打印内容
// NSLog(@"%d",a)
print(a)




