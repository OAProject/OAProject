//: Playground - noun: a place where people can play

import UIKit

// 1:定义数组-是一个范型集合，必须告诉它里面存那种类型数据
// 1> 定义不可变数组：使用let 修饰标志符定义出来的数组就是不可变数组
let array  = ["why","yz","iny","any"]
//或者 let array1 : Array<String>  = ["why","yz","iny","any","124"]
//或者 let array2 : [String]  = ["why","yz","iny","any","wer"]




// 2> 定义可变数组：使用var 修饰标志符定义出来的数组就是可变数据
//var arrayM = Array<String>()
var arrayM1 = [String]()




// 2:对可变数组的基本操作

// 2.1 添加元素
arrayM1.append("123")
arrayM1.append("abc")
arrayM1.append("ABC")


// 2.2 删除元素
arrayM1.removeAtIndex(0)



// 2.3  修改元素
arrayM1[0] = "lsb"
arrayM1


// 2.4   取出某一个元素
arrayM1[1]






// 3:数组的遍历<1.2重要掌握>

// 3.1 > 根据下标值进行遍历
for i in 0..<array.count {
    print(array[i]);
}

// 3.2 > 直接遍历数组中的元素
for name in array {
    print(name)
}


// 3.3 >遍历数组中前两个元素

for i in 0..<2 {
    print(array[i])
}

for name in array[0..<2] {
    print(name)
}




// 4:数组的合并

let resultArray = array + arrayM1

// 注意：相同类型的数组才可以进行合并，不同类型不能相加合并
// 就是数组里面存放的元素不一样的话是不能相加合并操作的
// 但是可变数组和不可变数组是没有影响的，只有里面存放的元素类型是否一致性才可以是否合并

//let array01 = ["qwe",18,1.88]
//let array02 = ["sdf","adaf"]
//let result03 = array01 + array02





