//: Playground - noun: a place where people can play

import UIKit

// OC写法
//for (int i=0;i<10;i++) {
//    NSLog(@"%d", i);
//}

// swift 写法
// for 后面()可以省略
// 1>for 循环的基本写法

for var i = 0 ; i < 10 ; i++ {
    print(i)
}


// 2> for循环的forin写法

for i in 0..<10 {
    print(i)
}




// 3> for循环forin写法（特殊）
// 在swift中，如果一个标志符不需要使用，可以使用_代替
for i in 0...9 {
    print("hello world!")
}

// 如:
for _ in 0...9 {
    print("hello world！")
}









