//: Playground - noun: a place where people can play

import UIKit

// guard 只能是在函数中使用

let age = 20


func online(age : Int) {
    if age >= 18 {
        print("可以留下来上网")
    }else {
        print("回家找妈妈")
    }
}

// 函数只有调用的时候才会打印
online(age)




//  可读性不强

//func online(age : Int) {
//    if age >= 18 {
//        print("可以留下来上网")
//        if 带了身份证 {
//            print("开机上网")
//            if 带了钱 {
//                print("开卡去找机子")
//            }else {
//                print("回家拿钱")
//            }
//        }else {
//            print("回家拿身份证")
//        }
//    }else {
//        print("回家找妈妈")
//    }
//}

// 函数只有调用的时候才会打印
//online(age)



// ---------对比guard-----------------对比guard-----------------对比guard


func online1 (age : Int) {
    guard age >= 18 else {
        // 条件不成立false才执行这个
       print("回家找妈妈")
       return
    }
    // 条件成立ture才执行
    print("留下来")
}

online1(age)


// 可读性很强，阅读行很好

//func online1 (age : Int) {
//    guard age >= 18 else {
//        // 条件不成立false才执行这个
//        print("回家找妈妈")
//        return
//    }
//    
//    guard 带了钱 else {
//        print("回家拿钱")
//        return
//    }
//    
//    guard 带了身份证 else {
//        print("回家拿身份证")
//        return
//    }
//    
//    
//    // 条件成立ture才执行
//    print("留下来")
//    print("刷卡上网")
//    print("开机上网")
//}
//
//online1(age)












