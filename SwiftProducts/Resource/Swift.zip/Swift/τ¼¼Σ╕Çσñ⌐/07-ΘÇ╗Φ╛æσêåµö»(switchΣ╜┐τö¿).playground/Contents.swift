//: Playground - noun: a place where people can play

import UIKit

// 1:switch基本用法

// 0 : 男  1 :女
let sex = 0

// 1>switch后面的()可以省略
// 2>case语句结束后,break也可以省略,系统默认会给你加上

//switch sex {
//case 0:
//    print("男")
//case 1:
//    print("女")
//default:
//    print("其他")
//}





// 2:基本用法的补充
// 2.1>如果系统某一个case中产生case穿透,可以在我们case结束后更上fallthrough
// 2.2>case后面可以判断多个条件,多个条件以,分割
switch sex {
    case 0, 1:
        print("正常人")
    default:
        print("其他")
}







// 3:swift中switch特殊用法 
// 3.1:switch可以判断浮点型
let a = 3.14
//
//switch 3.1 {
//    case 3.14:
//        print("pai")
//    default:
//        print("非pai")
//}

switch a {
case 2:
    print("sss")
default:
    print("ddddd")
}




// 3.2.switch可以判断字符串
let m = 20
let n = 30

var result = 0

let opration = "+"
switch opration {
    case "+":
    result = m + n
    case "-":
    result = m - n
    case "*":
    result = m * n
    case "/":
    result = m / n
default:
    print("非法操作")
}



// 3.3.switch可以判断区间
// 区间:开区间 0..<20 0~19  比区间 0...20 0~20

let score = 88

switch score {
case 0..<60:
    print("不及格")
case 60..<80:
    print("及格")
case 80..<90:
    print("良好")
case 90...100:
    print("优秀")

default:
    print("不合理分数")
}









