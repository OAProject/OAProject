//: Playground - noun: a place where people can play

import UIKit

// 1:定义字典
// 1> 定义不可变字典：使用let修饰
// 系统会自动判断后面的[]中存放的是键值对，还是一个一个的元素
let dict = ["name":"lisi","age":20,"height":1.86]
//或者 let dict1 : Dictionary<String,NSObject> = ["name":"lisi","age":20,"height":1.86]
//或者 let dict2 : [String:NSObject] = ["name":"lisi","age":20,"height":1.86]




// 2> 定义可变字典：使用var修饰
// var dictM = Dictionary<String,NSObject>()
// AnyObject:一般指定类型  NSObject:一般用于创建对象
var dictM = [String : NSObject]()

//  一般使用这个
var dictM1 = [String : AnyObject]()







// 2:对可变字典的基本操作       <增删改查>

// 2.1 添加元素
dictM1["name"] = "lisi"
dictM1

dictM1["age"] = 19
dictM1["height"] = 1.88
dictM1["weight"] = 79
dictM1["gender"] = "男"

dictM1


// 2.2 删除元素
dictM1.removeValueForKey("weight")
dictM1

// 2.3 修改元素
// 区别：如果字典中已经有了对应的key，那么会直接修改原来key中保存的值value
// 如果字典中没有对应的key，那么添加对应的key／value

dictM1["name"] = "zhangsan"
dictM1



// 2.4  获取某一个元素
dictM1["age"]



// 3:字典的遍历

// 3.1 遍历字典中所有的key
for key in dictM1.keys {
    print(key)
}


// 3.2 遍历字典中所有的值value
for value in dictM1.values {
    print(value)
}

// 3.3 遍历所有的键值对
for (key,value) in dictM1 {
    print(key,value)
}



// 4:合并字典
// 即使类型一致也不能相加进行合并
var dict01 = ["name":"adf","age":1.11]
let dict02 = ["phone":"18655062536","height":1.80]
//let result = dict01 + dict02    错误写法


//  遍历不可变数组，将不可变数组中所有值加入到可变数组中去
for (key, value) in dict02 {
    dict01[key] = value
}

dict01

dict02








