//: Playground - noun: a place where people can play

import UIKit




//1:定义字符串
let opration = "+"
let str = "hello world"





// 2:遍历字符串
for c in str.characters {
    print(c)
}





// 3:字符串的拼接
// 3.1 两个字符串之间的拼接

let str1 = "abc"
let str2 = "ABC"
let str3 = str1 + str2

// 3.2:字符串和其他标志符之间的拼接
let name = "wiye"
let age = 18
let height = 1.88

let info = "my name is \(name),my age is \(age),my height is \(height)"


// 3.3拼接字符串时，字符串的格式化
let min = 2
let second  = 8
//let timeString = "\(min):0\(second)"

String(format: "%02d:%02d", arguments: [min,second])






//4:字符串的截取
let urlString = "www.520it.com"
// 将string类型转成NSString类型 (string as NSString)
let header = (urlString as NSString).substringToIndex(3)

let middle = (urlString as NSString).substringWithRange(NSMakeRange(4, 5))

let footer = (urlString as NSString).substringFromIndex(10)







