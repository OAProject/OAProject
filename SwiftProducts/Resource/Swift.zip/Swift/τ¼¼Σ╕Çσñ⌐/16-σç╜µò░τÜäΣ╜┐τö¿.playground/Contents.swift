//: Playground - noun: a place where people can play

import UIKit

// swift格式：
//func 方法名字(参数列表) ->（返回值类型）

// 1:没有参数 没有返回值
func about() ->Void {
    print("iphone7")
}
about()

func about1() {
    print("iphone7-1")
}
about1()



// 2:没有参数 有返回值

func readMessage() -> String {
    return("吃饭了嘛")
}
readMessage()
print(readMessage())




// 3:有参数 没有返回值
func callPhone(phoneNum : String) {
    print("打电话给" + phoneNum)
}
callPhone("+86 110")




// 4:有参数 有返回值

func sum(num1 : Int, num2 : Int) -> Int {
    return num1 + num2
}

sum(20, num2: 30)
print(sum(20, num2: 30))
