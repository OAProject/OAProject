//: Playground - noun: a place where people can play

import UIKit

import UIKit

let m : Int = 10

// 创建一个常量对象
// OC创建对象:[[UIView alloc] init]
// swift 创建对象：UIView()
let view : UIView = UIView()
//view = UIView()  错误写法

view.backgroundColor = UIColor.redColor()
view.frame = CGRectMake(0, 0, 100, 200)
view.alpha = 0.5

//OC-------- BOOL :YES/NO
//swift----- BOOL :true/false
view.hidden = true
