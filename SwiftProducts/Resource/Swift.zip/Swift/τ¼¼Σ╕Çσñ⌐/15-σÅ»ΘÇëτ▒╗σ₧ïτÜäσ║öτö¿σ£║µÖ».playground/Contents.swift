//: Playground - noun: a place where people can play

import UIKit

// 通过一个字符串创建一个NSURL对象
let url = NSURL(string:"http://www.520it.com")
//let url1 : NSURL? = NSURL(string:"http://www.520it.com")

print(url)
// 根据url 创建NSURLRequest对象
//let request = NSURLRequest(URL: url!)
//if url != nil {
//    let request = NSURLRequest(URL: url!)
//}

// 推荐使用
if let url = url {
    let request1 = NSURLRequest(URL: url)
}
