//: Playground - noun: a place where people can play

import UIKit

// 1:使用数组定义一组数组
let array = ["avc",18,1.88]
array[0]
array[1]
array

// 2:使用字典定义一组数组
let dict = ["name":"lisi","age":18]
dict


// 3:使用元组定义一组数组 (一般用于作为方法的返回值)
// 3.1元组的基本写法
let info = ("avc",18,1.88)
info.0
info.1


// 3.2可以给元组每一个元素起一个别名(常见写法)
let info1 = (name : "avc",age : 18,height : 1.88)
info1.name
info1.age
info1.height


// 3.3  元组中元素的别名，就是元组的名称
let (name, age, height) = ("why",18,1.88)
name
age
height

































