//: Playground - noun: a place where people can play

import UIKit

var a = 10


// OC 写法
//while (a) {
//    
//}


// swift 写法
// 1>while后面的（）可以省略
// 2>while后面的判断没有非0即为真

while a > 0 {
    print(a)
    a -= 1
}


// swift 中do while 循环需要写成 repeat while

repeat  {
    print(a)
    a += 1
}while a < 10















