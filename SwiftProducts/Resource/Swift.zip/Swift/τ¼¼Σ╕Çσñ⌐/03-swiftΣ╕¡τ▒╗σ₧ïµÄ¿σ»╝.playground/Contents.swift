//: Playground - noun: a place where people can play

import UIKit

//swift :强类型语言
// 按住option键 ，出现一个？，然后点击变量或者常量，就会出现类型

//let a :Int = 10
//  简洁写法:
let a = 10

let b = 2.44
let view = UIView()
let btn = UIButton()
//var m = 10




//－－－－－－－－－－－－－－－－－－－－－－

//var n   错误写法
//n = 20

var m :Int
m = 20



//－－－－－－－－－－－－－－－－－－－－－－－

// 下面这个没有初始化，没有保存地址
let p :Int
p = 40


// 下面这个已经初始化过，已经有了内存地址
//let a :Int = 0  错误写法
//a = 100






